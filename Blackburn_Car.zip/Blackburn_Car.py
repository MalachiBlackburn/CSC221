##This program uses the car class
import car

def main():
    ##local variables
    car_year_model = 0
    car_make = ""
    


    car_year_model = int(input("Enter the model year of the car: "))
    car_make = input("Enter the make of the car: ")
    

    ##Create an instance of the car class

    mycar = car.Car(car_year_model, car_make)

    ## Display car Info

    print("Here is your car's name:", mycar.get_year_model())
    print("Here is your car's type:", mycar.get_make())
    
    print("Acceleration")
    for i in range(5):
        mycar.accelerate()
        print("Current Accelerated Speed =",mycar.get_speed())
    print("Brake")
    for i in range(5):
        mycar.brake()
        print("Current Brake Speed =", mycar.get_speed())
    


    
    
    












main()
