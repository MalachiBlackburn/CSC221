##Malachi
##May 3rd

import pinfo

def main():
    name = ""
    address = ""
    age = 0
    phone_number = 0

    person1 = pinfo.PInfo("Malachi", "3312 Amour Dr.", "17", "3346146915")
    person2 = pinfo.PInfo("Rachad", "6458 Broke Boy Ln.", "16", "18002738255")
    person3 = pinfo.PInfo("Peter", "1234 Trench Coat Ct.", "18", "6789998212")

    print(person1.get_name(), person1.get_address(), person1.get_age(), person1.get_phone_number())
    print(person2.get_name(), person2.get_address(), person2.get_age(), person2.get_phone_number())
    print(person3.get_name(), person3.get_address(), person3.get_age(), person3.get_phone_number())

        
                        












main()
