import employee

def main():
    employee_name = ""
    employee_ID = 0
    employee_department = ""
    employee_title = ""
    
    for i in range(3):
   
        employee_name = input("Enter the employee's name: ")
    
        employee_ID = int(input("Enter the employee's ID Number: "))
    
        employee_department = input("Enter the employee's department name: ")
    
        employee_title = input("Enter the employee's job title: ")
    
        my_employee = employee.Employee(employee_name, employee_ID, employee_department, employee_title)
    
    
        print("Employee Name: ", my_employee.get_name())
        
        print("Employee ID: ", my_employee.get_ID())
        
        print("Employee Department: ", my_employee.get_department())
        
        print("Employee Job Title: ", my_employee.get_title())



main()
       

    
    
